This script tests various permutations of VirtualGL settings against
VirtualGL's implementation of glxinfo and stores the results in the
~/.glxinfotest directory, which can be managed with Git in order to guard
against regressions in VirtualGL's visual matching algorithms.
