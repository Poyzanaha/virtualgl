The Mac VirtualGL Client is an X-Windows program that requires the Mac X11
application or XQuartz.  The VirtualGL Client must be launched from an xterm or
Terminal window.  Refer to the VirtualGL User's Guide for usage instructions.
